Features:
- A regular HTML table with various DOM manipulation functionalities to vaidate the form.
- On submit button form details were vaidated
- On incorrect fill of the phone no , zip code, email and error is displayed.
- On submit of form the details filled are displyed in the table format at bottom.
- Cutomization option available for drinks.
- On reset the page is reloaded.
- Doument.getelementbyID and document.getelementbyclass is used.
- Javascript fucntions are defined for perform the actions on button click events

Setup:
- Open the table.html file on vscode
- Run the application with live server (VS Code extension).